package pack;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Remove;
import javax.ejb.*;
@Stateful
public class CartBean implements CartBeanRemote
{ String customerName;
 String customerId;
 List<String> contents;
 public void initialize(String person, String id)
 throws Exception 
 { if (person == null) 
 { throw new Exception("Null person not allowed.");
 } else 
 { customerName = person; }
 if ( person=="ABC" && id=="123") 
 { customerId = id;
 } else 
 { throw new Exception("Invalid id: " + id); }
 contents = new ArrayList<String>();
 }
 public void addBook(String title) 
 { contents.add(title); }
 public void removeBook(String title) throws Exception 
 { boolean result = contents.remove(title);
 if (result == false) 
 { throw new Exception(title + " not in cart.");
 }
 }
 public List<String> getContents() 
 { return contents; }
 @Remove
 public void remove() 
 { contents = null; }
}
