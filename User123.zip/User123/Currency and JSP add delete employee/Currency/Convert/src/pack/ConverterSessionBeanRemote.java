
package pack;

import java.math.BigDecimal;
import javax.ejb.Remote;

@Remote
public interface ConverterSessionBeanRemote 
{
    public BigDecimal dollarToYen(BigDecimal dollars);
    public BigDecimal yenToEuro(BigDecimal yen);

}
