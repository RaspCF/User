package jdbc2;
import java.sql.*;
import java.util.*;


     class JDBC2
     {
    Connection  con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    ResultSetMetaData rsmd;
    JDBC2()
    {
       try
       {
           Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
           
       }
           catch(ClassNotFoundException e)
           {
               System.out.println(e);
           }
          try
          {
         con=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=db3;username=sa;password=123456");
         stmt=con.createStatement();
         Scanner sc = new Scanner(System.in);
         Scanner sc1 = new Scanner(System.in);
         int roll_no;
         String name, addr;
         char ch;
          
           do
          {
           System.out.println("Enter Student Details");
           System.out.println("Enter Roll_no");
           roll_no=sc.nextInt();
           System.out.println("Enter name");
           name=sc.next();
           System.out.println("Enter address");
           addr=sc1.nextLine();
           String str="insert into Student1 values(?,?,?)";
           pstmt=con.prepareStatement(str);
           pstmt.setInt(1,roll_no);
           pstmt.setString(2,name);
           pstmt.setString(3,addr);
           pstmt.executeUpdate();
           System.out.println("Do you want insert one more record(y/n)?");
           ch=sc.next().charAt(0);
       }while(ch =='y' || ch=='y');
       rs=stmt.executeQuery("Select * from Student1");
       rsmd=rs.getMetaData();
       int cols=rsmd.getColumnCount();
        for(int i=1;i<=cols;i++)
        {
            System.out.print(rsmd.getColumnName(i)+"\t");
        }
           System.out.println();
            while(rs.next())
            {
                System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
                
            }
        }
         catch(SQLException e)
         {
               System.out.println(e);
               
        }
    }
    public static void main(String[] args)
     {
        new  JDBC2();
     }
}
           
             
                     
                     
           
           
               
       
       
       
      
       
           
       

    
    
        
    
    

